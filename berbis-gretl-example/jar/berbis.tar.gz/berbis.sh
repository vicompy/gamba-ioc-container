#!/bin/bash

java -cp berbis.jar org.berbis.getl.CMain

